-- Run this once in Supabase: Dashboard -> SQL Editor -> New Query -> paste all -> Run

create extension if not exists "pgcrypto";

create table if not exists profiles (
  id uuid primary key,
  name text not null,
  age int,
  year text,
  major text,
  interests text[],
  bio text,
  school text,
  avatar_url text,
  created_at timestamptz default now()
);

create table if not exists group_members (
  group_id text not null,
  profile_id uuid references profiles(id) on delete cascade,
  joined_at timestamptz default now(),
  primary key (group_id, profile_id)
);

create table if not exists group_posts (
  id uuid primary key default gen_random_uuid(),
  group_id text not null,
  author_id uuid references profiles(id) on delete cascade,
  author_name text not null,
  text text not null,
  created_at timestamptz default now()
);

create table if not exists messages (
  id uuid primary key default gen_random_uuid(),
  sender_id uuid references profiles(id) on delete cascade,
  recipient_id uuid references profiles(id) on delete cascade,
  text text not null,
  created_at timestamptz default now()
);

alter table profiles enable row level security;
alter table group_members enable row level security;
alter table group_posts enable row level security;
alter table messages enable row level security;

-- These policies allow anyone with your anon key (i.e. anyone who has your
-- deployed link) to read and write. That's intentional for a small, trusted
-- beta test with people you know -- it is NOT secure for a public launch.
-- Before opening this up widely, add real authentication (Supabase Auth)
-- and scope these policies to "only the logged-in user's own rows."

create policy "public read profiles" on profiles for select using (true);
create policy "public insert profiles" on profiles for insert with check (true);
create policy "public update profiles" on profiles for update using (true);

create policy "public read group_members" on group_members for select using (true);
create policy "public insert group_members" on group_members for insert with check (true);
create policy "public delete group_members" on group_members for delete using (true);

create policy "public read group_posts" on group_posts for select using (true);
create policy "public insert group_posts" on group_posts for insert with check (true);

create policy "public read messages" on messages for select using (true);
create policy "public insert messages" on messages for insert with check (true);
