# College Connect — Beta Setup

No coding required for these steps — just clicking through free dashboards.
Budget about 20–30 minutes the first time.

## 1. Create your database (Supabase)

1. Go to supabase.com → sign up (free) → "New Project"
2. Pick any name/password, wait ~2 min for it to spin up
3. In the left sidebar, click **SQL Editor** → **New query**
4. Open `supabase/schema.sql` in this folder, copy all of it, paste it in, click **Run**
   - This creates the tables (profiles, groups, posts, messages) that let
     everyone see each other, instead of each phone having its own private copy
5. In the left sidebar, click **Project Settings → API**
6. Copy the **Project URL** and the **anon public** key — you'll need both next

## 2. Put the project on GitHub

1. Go to github.com → sign up if you don't have an account → **New repository**
2. Name it `college-connect`, keep it **Private** (recommended for a beta), create it
3. On the new repo page, click **uploading an existing file**
4. Drag in every file and folder from this project, commit

## 3. Deploy it (Vercel)

1. Go to vercel.com → sign up with your GitHub account
2. **Add New → Project** → select your `college-connect` repo → **Import**
3. Vercel will auto-detect it's a Vite app — leave the defaults
4. Before clicking Deploy, open **Environment Variables** and add:
   - `VITE_SUPABASE_URL` → paste the Project URL from step 1
   - `VITE_SUPABASE_ANON_KEY` → paste the anon public key from step 1
5. Click **Deploy**. In about a minute you'll get a live link like
   `college-connect-yourname.vercel.app`

## 4. Set your invite code

Open `src/App.jsx`, find this near the top:

```js
const BETA_CODE = "TEST26";
```

Change `"TEST26"` to whatever you want testers to type in. Re-upload that one
file to GitHub (or re-commit) and Vercel will redeploy automatically.

## 5. Invite real testers

Text or email people the Vercel link + your invite code. Ask them to actually
try posting in a group, messaging someone, and setting up their profile —
and to tell you what's confusing.

## Good to know before you send it out

- **This is a beta-grade security setup, not production-grade.** Anyone with
  your Vercel link and invite code can read and write the shared database —
  fine for a small group of people you trust, not something to open publicly
  without adding real user authentication first.
- **Profile photos are stored as embedded image data**, not in proper file
  storage — fine for a small test, but this will get slow/expensive at scale.
  A real launch should move to Supabase Storage.
- **Messages refresh every few seconds while a chat is open**, not instantly —
  good enough for testing, not true real-time chat yet.
- Want it to feel like an app on someone's phone? After they open the link,
  they can tap Share → **Add to Home Screen** (iOS Safari) or the equivalent
  in Chrome — it'll launch full-screen with an icon, no App Store needed.
